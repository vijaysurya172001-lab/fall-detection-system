"""
ACTIVITY DETECTION GEOMETRY & LOGIC
This module contains the math and logic to identify human positions 
based on AI-detected pose landmarks, following the standard 11-activity schema.
"""

import time
import math

def detect_activity_from_pose(landmarks):
    """
    HUMAN ACTIVITY CLASSIFIER (11 Categories)
    
    Mapped Categories:
    1: Falling forward (hands)
    2: Falling forward (knees)
    3: Falling backwards
    4: Falling sideways
    5: Falling sitting
    6: Walking
    7: Standing
    8: Sitting
    9: Picking up object
    10: Jumping
    11: Laying
    """
    if landmarks is None or not landmarks.pose_landmarks:
        return 20, "Detecting Person..."
    
    lm = landmarks.pose_landmarks.landmark
    
    # --- KEY BODY POINTS ---
    nose = lm[0]
    left_shoulder, right_shoulder = lm[11], lm[12]
    left_hip, right_hip = lm[23], lm[24]
    left_knee, right_knee = lm[25], lm[26]
    left_ankle, right_ankle = lm[27], lm[28]
    left_wrist, right_wrist = lm[15], lm[16]
    
    # --- CENTER POINTS & RATIOS ---
    shoulder_y = (left_shoulder.y + right_shoulder.y) / 2
    shoulder_x = (left_shoulder.x + right_shoulder.x) / 2
    hip_y = (left_hip.y + right_hip.y) / 2
    hip_x = (left_hip.x + right_hip.x) / 2
    knee_y = (left_knee.y + right_knee.y) / 2
    ankle_y = (left_ankle.y + right_ankle.y) / 2
    
    torso_len = abs(shoulder_y - hip_y)
    leg_len = abs(hip_y - ankle_y)
    total_h = abs(nose.y - ankle_y)
    
    # --- MOTION TRACKING ---
    if not hasattr(detect_activity_from_pose, "prev_nose_y"):
        detect_activity_from_pose.prev_nose_y = nose.y
        detect_activity_from_pose.prev_time = time.time()
        detect_activity_from_pose.prev_v = 0
    
    curr_t = time.time()
    dt = curr_t - detect_activity_from_pose.prev_time
    delta_y = nose.y - detect_activity_from_pose.prev_nose_y
    
    velocity_y = 0
    if dt > 0:
        velocity_y = delta_y / dt
        detect_activity_from_pose.prev_nose_y = nose.y
        detect_activity_from_pose.prev_time = curr_t

    # 10. JUMPING: Sudden upward velocity followed by airborne state
    if velocity_y < -1.5 and ankle_y < 0.8:
        return 10, "Jumping"

    # 11. LAYING: Horizontal orientation
    horiz_span = abs(nose.x - left_ankle.x)
    vert_span = abs(nose.y - ankle_y)
    if horiz_span > vert_span * 1.3 and nose.y > 0.6:
        return 11, "Laying"

    # --- FALLING OVERVIEW ---
    is_falling = False
    if velocity_y > 2.0 and nose.y > 0.4: is_falling = True # Sudden drop
    
    body_angle = torso_len / (abs(left_shoulder.x - left_hip.x) + 0.01)
    if body_angle < 1.0 and nose.y > 0.5: is_falling = True # Body tilted

    if is_falling:
        # 5. Falling sitting: If hips are low but torso is somewhat upright
        if hip_y > 0.7 and torso_len > 0.15:
            return 5, "Falling sitting"
        
        # 3. Falling backwards: Head behind hips/shoulders
        if nose.x > shoulder_x + 0.1:
            return 3, "Falling backwards"
        
        # 4. Falling sideways: Significant tilt to left or right
        if abs(left_shoulder.y - right_shoulder.y) > 0.15:
            return 4, "Falling sideways"
            
        # 1 & 2. Falling forward
        if nose.x < shoulder_x - 0.05:
            # 1. Forward (hands): Wrists are out in front
            if left_wrist.y < nose.y or right_wrist.y < nose.y:
                return 1, "Falling forward (hands)"
            # 2. Forward (knees): Wrists not protecting, knees leading
            return 2, "Falling forward (knees)"
        
        return 1, "Fall Detected"

    # 9. PICKING UP OBJECT: High hip, low head/wrists
    if hip_y < 0.6 and (left_wrist.y > 0.8 or right_wrist.y > 0.8) and torso_len < 0.2:
        return 9, "Picking up object"

    # 8. SITTING & POSTURE
    # If knees and hips are at similar level, or lower body invisible
    if abs(hip_y - knee_y) < 0.15 or (left_hip.visibility < 0.5):
        if total_h < 0.5 or hip_y > 0.6:
            # Posture sub-logic
            shoulder_tilt = abs(left_shoulder.y - right_shoulder.y)
            nose_off = abs(nose.x - shoulder_x)
            if shoulder_tilt < 0.04 and nose_off < 0.05:
                return 8, "Sitting (Good Posture)"
            else:
                return 8, "Sitting (Bad Posture)"

    # 6. WALKING: Leg movement detected
    if abs(left_ankle.x - right_ankle.x) > 0.15 and total_h > 0.5:
        return 6, "Walking"

    # 7. STANDING: Default upright
    if total_h > 0.4:
        return 7, "Standing"

    return 7, "Standing"
