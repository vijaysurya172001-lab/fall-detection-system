@echo off
echo ==========================================
echo Fall Detection Project - Startup Script
echo ==========================================

echo [1/3] Checking dependencies...
pip install opencv-python scikit-learn numpy joblib pandas==1.3.5 mediapipe==0.8.8

echo.
echo [2/3] Verifying ML models...
if not exist fall_model_RF.pkl (
    echo Models not found. Training now...
    python train_mock.py
) else (
    echo Models already exist.
)

echo.
echo [3/3] Starting Fall Detection System...
python main.py

pause
